from abc import ABC, abstractmethod

class BaseProvider(ABC):
    @abstractmethod
    def generate(self, prompt: str, temperature: float = 0.7) -> str:
        pass

    @abstractmethod
    async def agenerate(self, prompt: str, temperature: float = 0.7) -> str:
        pass

    @abstractmethod
    def count_tokens(self, text: str) -> int:
        pass
        
    @abstractmethod
    async def acount_tokens(self, text: str) -> int:
        pass

    @abstractmethod
    def model_name(self) -> str:
        pass

    def cost_per_1k_tokens(self) -> float:
        """
        Estimated cost in USD per 1,000 tokens (input+output combined) for this
        provider/model. Subclasses should override with real pricing; defaults
        to 0.0 so unpriced providers don't silently report inflated savings.
        """
        return 0.0
